import { useState, useCallback } from "react";
import { ChatMessage, Publication, ClinicalTrial } from "@/types/chat";
import { mockPublications, mockTrials } from "@/data/mockData";

export const useChatStore = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [publications, setPublications] = useState<Publication[]>([]);
  const [trials, setTrials] = useState<ClinicalTrial[]>([]);
  const [disease, setDisease] = useState("");
  const [location, setLocation] = useState("");
  const [loading, setLoading] = useState(false);

  const addMessage = useCallback((role: "user" | "assistant", content: string) => {
    const msg: ChatMessage = {
      id: crypto.randomUUID(),
      role,
      content,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, msg]);
  }, []);

  const handleSend = useCallback(
    async (userMessage: string) => {
      if (!userMessage.trim()) return;
      addMessage("user", userMessage);
      setLoading(true);

      // Simulate API delay and mock response
      await new Promise((r) => setTimeout(r, 2000));

      // Simulate extracting disease/location
      const lowerMsg = userMessage.toLowerCase();
      if (lowerMsg.includes("lung cancer")) setDisease("Lung Cancer");
      else if (lowerMsg.includes("diabetes")) setDisease("Type 2 Diabetes");
      else if (lowerMsg.includes("parkinson")) setDisease("Parkinson's Disease");
      else if (lowerMsg.includes("breast cancer")) setDisease("Breast Cancer");
      else setDisease(userMessage.split(" ").slice(0, 3).join(" "));

      if (lowerMsg.includes("mumbai")) setLocation("Mumbai, India");
      else if (lowerMsg.includes("london")) setLocation("London, UK");
      else if (lowerMsg.includes("new york")) setLocation("New York, USA");

      setPublications(mockPublications);
      setTrials(mockTrials);

      addMessage(
        "assistant",
        `Based on the latest research, here are key insights for your query about **${userMessage.slice(0, 60)}**:\n\n` +
          `### Key Findings\n\n` +
          `1. **Immunotherapy Advances**: Recent studies show significant progress in checkpoint inhibitors, with pembrolizumab + chemotherapy showing improved overall survival rates of up to 22 months in advanced cases.\n\n` +
          `2. **Early Detection**: A novel deep learning framework achieved **94.3% sensitivity** in early detection using low-dose CT scans, published in Nature Medicine (2024).\n\n` +
          `3. **Targeted Therapy**: For EGFR-mutated cases, third-generation TKIs have shown improved progression-free survival compared to standard chemotherapy.\n\n` +
          `### Active Clinical Trials\n\n` +
          `I found **${mockTrials.length} active clinical trials** relevant to your condition. The most notable is a Phase III study (NCT05847291) currently recruiting patients.\n\n` +
          `> ⚠️ *This information is for research purposes only. Please consult your healthcare provider for personalized medical advice.*`
      );

      setLoading(false);
    },
    [addMessage]
  );

  const clearSession = useCallback(() => {
    setMessages([]);
    setPublications([]);
    setTrials([]);
    setDisease("");
    setLocation("");
  }, []);

  return {
    messages,
    publications,
    trials,
    disease,
    location,
    loading,
    handleSend,
    clearSession,
  };
};
